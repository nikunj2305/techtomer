@extends ('backend.layouts.app')

@section ('title', trans('Career Management'))

@section('page-header')
    <h1>{{ trans('Career Management') }}</h1>
@endsection

@section('content')
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title">{{ trans('Career Management') }}</h3>

            <div class="box-tools pull-right">
                @include('backend.careers.partials.header-buttons')
            </div>
        </div><!-- /.box-header -->

        <div class="box-body">
            <div class="table-responsive data-table-wrapper">
                <table id="faqs-table" class="table table-condensed table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Name</th>
                            <th>Vacancy</th>
                            <th>Work Status</th>
                            <th>Exp</th>
                            <th>Technology</th>
                            <th>{{ trans('Active') }}</th>
                            <th>{{ trans('Created At') }}</th>
                            <th>{{ trans('labels.general.actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(isset($data) && !empty($data))
                            @foreach($data as $k=>$v)
                                <tr>
                                    <td>{!! $k+1 !!}</td>
                                    <td>{!! $v->name !!}</td>
                                    <td>{!! $v->vacancy !!}</td>
                                    <td>{!! $v->work_status !!}</td>
                                    <td>{!! $v->exp !!}</td>
                                    <td>{!! $v->technology !!}</td>
                                    <td>
                                        @if($v->is_active == 'Yes')
                                         <span class="btn btn-success">Yes</span>
                                        @else
                                         <span class="btn btn-danger">No</span>
                                        @endif
                                    </td>
                                    <td>{!! date('d M-Y',strtotime($v->created_at)) !!}</td>
                                    <td>
                                        <div class="btn-group action-btn">
                                            <a class="btn btn-default btn-flat" href="{!! URL::to('admin/career/edit'.'/'.$v->id) !!}">
                                                <i data-toggle="tooltip" data-placement="top" title="" class="fa fa-pencil" data-original-title="Edit"></i>
                                            </a>
                                            <a class="btn btn-default btn-flat" href="{!! URL::to('admin/career/delete'.'/'.$v->id) !!}">
                                                <i class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="Delete"></i>
                                            </a>
                                                @if($v->is_active == 'Yes')
                                                    <a class="btn btn-default btn-flat" href="{!! URL::to('admin/career/status'.'/'.$v->id.'/No') !!}">
                                                        <i class="fa fa-square" data-toggle="tooltip" data-placement="top" title="Deactivate"></i>
                                                    </a>
                                                @else
                                                    <a class="btn btn-default btn-flat" href="{!! URL::to('admin/career/status'.'/'.$v->id.'/Yes') !!}">
                                                        <i class="fa fa-check-square" data-toggle="tooltip" data-placement="top" title="Activate"></i>
                                                    </a>
                                                @endif
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div><!--table-responsive-->
        </div><!-- /.box-body -->
    </div><!--box-->

@endsection

@section('after-scripts')
    {{-- For DataTables --}}
    {{ Html::script(mix('js/dataTable.js')) }}

    <script>
        
            $('#faqs-table').dataTable();
        
    </script>
@endsection