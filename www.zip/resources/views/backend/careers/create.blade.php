@extends ('backend.layouts.app')

@section ('title', trans('Career Management') . ' | ' . trans('Create Career'))

@section('page-header')
    <h1>
        {{ trans('Career Management') }}
        <small>{{ trans('Create Career Post') }}</small>
    </h1>
@endsection

@section('content')
    {{ Form::open(['route' => 'admin.career.create.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-faq', 'files' => true]) }}

        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">{{ trans('Create Career') }}</h3>

                <div class="box-tools pull-right">
                    @include('backend.careers.partials.header-buttons')
                </div><!--box-tools pull-right-->
            </div><!-- /.box-header -->

            {{-- Including Form blade file --}}
            <div class="box-body">
                <div class="form-group">
                    <div class="box-body">

                        <div class="form-group">
                            {{ Form::label('name', trans('Name'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('name', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Post Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_name', trans('Germany Name'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('de_name', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Post Germany Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('sort_description', trans('Listing Page Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('sort_description', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Listing Page Description'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_sort_description', trans('Germany Listing Page Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('de_sort_description', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Germany Listing Page Description'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('description', trans('Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('description', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Description'), 'required' => 'required', 'id' => 'editor']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_description', trans('Germany Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('de_description', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Germany Description'), 'required' => 'required', 'id' => 'editor1']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('vacancy', trans('No of Vacancy'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('vacancy', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Number of Vacancy'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('work_status', trans('Work Status'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('work_status', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Work Status (full time)'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('exp', trans('exp'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('exp', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Exp'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('technology', trans('Technology'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('technology', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Technology'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('status', trans('STATUS'), ['class' => 'col-lg-2 control-label']) }}

                            <div class="col-lg-10">
                                <div class="control-group">
                                    <label class="control control--checkbox">
                                        
                                            {{ Form::checkbox('is_active', 1, true) }}
                                        
                                        <div class="control__indicator"></div>
                                    </label>
                                </div>
                            </div><!--col-lg-3-->
                        </div><!--form control-->
                    </div>
                    </div>
                    <div class="edit-form-btn">
                    {{ link_to_route('admin.career.list', trans('buttons.general.cancel'), [], ['class' => 'btn btn-danger btn-md']) }}
                    
                    {{ Form::submit(trans('buttons.general.crud.create'), ['class' => 'btn btn-primary btn-md']) }}
                    <div class="clearfix"></div>
                </div>
            </div>
        </div><!--box-->
    </div>
    {{ Form::close() }}
@endsection

@section('after-scripts')
    <script src="https://cdn.ckeditor.com/4.15.0/full/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('editor',{
            baseFloatZIndex: 10005
        });

        CKEDITOR.replace('editor1',{
            baseFloatZIndex: 10005
        });
    </script>
@endsection