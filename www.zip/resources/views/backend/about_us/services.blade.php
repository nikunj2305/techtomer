@extends ('backend.layouts.app')

@section ('title', trans('About us') . ' | ' . trans('Services'))

@section('page-header')
    <h1>
        {{ trans('About us: Services') }}
        <small>{{ trans('Edit Data') }}</small>
    </h1>
@endsection

@section('content')
    {{ Form::open(['route' => 'admin.aboutus.update', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-faq', 'files' => true]) }}
        <input type="hidden" name="id" value="{!! $data->id !!}">
        <input type="hidden" name="old_image" value="{!! $data->image !!}">
        <input type="hidden" name="slug" value="services">

        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">{{ trans('Edit Service') }}</h3>

                <div class="box-tools pull-right">
                    @include('backend.products.partials.header-buttons')
                </div><!--box-tools pull-right-->
            </div><!-- /.box-header -->

            {{-- Including Form blade file --}}
            <div class="box-body">
                <div class="form-group">
                    <div class="box-body">

                        <div class="form-group">
                            {{ Form::label('name', trans('Title'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('title', $data->title, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Title'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_name', trans('German Title'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('de_title', $data->de_title, ['class' => 'form-control box-size', 'placeholder' => trans('Enter German Title'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('image', trans('IMAGE'), ['class' => 'col-lg-2 control-label']) }}

                            <div class="col-lg-10">
                                {{ Form::file('image', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Subject Name')]) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('old_image', trans('OLD IMAGE'), ['class' => 'col-lg-2 control-label']) }}

                            <div class="col-lg-10">
                                <img src="{!! URL::to('img/about_us'.'/'.$data->image) !!}" style="height : 100px;">
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('description', trans('Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('description', $data->description, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Description'), 'required' => 'required', 'id' => 'editor']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_description', trans('German Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('de_description', $data->de_description, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Germany Description'), 'required' => 'required', 'id' => 'editor1']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        
                    </div>
                    <div class="edit-form-btn">
                        {{ link_to_route('admin.aboutus.services.list', trans('buttons.general.cancel'), [], ['class' => 'btn btn-danger btn-md']) }}
                    {{ Form::submit(trans('Update'), ['class' => 'btn btn-primary btn-md']) }}
                    <div class="clearfix"></div>
                </div>
            </div>
        </div><!--box-->
    </div>
    {{ Form::close() }}
@endsection
