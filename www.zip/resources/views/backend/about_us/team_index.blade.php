@extends ('backend.layouts.app')

@section ('title', trans('Teams'))

@section('page-header')
    <h1>{{ trans('Teams') }}</h1>
@endsection

@section('content')
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title">{{ trans('Teams') }}</h3>

            <div class="box-tools pull-right">
                @include('backend.products.partials.header-buttons')
            </div>
        </div><!-- /.box-header -->

        <div class="box-body">
            <div class="table-responsive data-table-wrapper">
                <table id="faqs-table" class="table table-condensed table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Name</th>
                            <th>German Name</th>
                            <th>{{ trans('Created At') }}</th>
                            <th>{{ trans('labels.general.actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(isset($data) && !empty($data))
                            @foreach($data as $k=>$v)
                                <tr>
                                    <td>{!! $k+1 !!}</td>
                                    <td>{!! $v->name !!}</td>
                                    <td>{!! $v->de_name !!}</td>
                                    
                                    <td>{!! date('d M-Y',strtotime($v->created_at)) !!}</td>
                                    <td>
                                        <div class="btn-group action-btn">
                                            <a class="btn btn-default btn-flat" href="{!! URL::to('admin/about-us/team/edit'.'/'.$v->id) !!}">
                                                <i data-toggle="tooltip" data-placement="top" title="" class="fa fa-pencil" data-original-title="Edit"></i>
                                            </a>
                                            
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div><!--table-responsive-->
        </div><!-- /.box-body -->
    </div><!--box-->
    
    {{ Form::open(['route' => 'admin.aboutus.update', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-faq', 'files' => true]) }}
    <input type="hidden" name="slug" value="team">
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title">{{ trans('Edit Team Text') }}</h3>
            <div class="box-body">
                <div class="form-group">
                    <div class="box-body">
                        <input type="hidden" name="slug" value="teams"> 
                        <div class="form-group">
                            {{ Form::label('title', trans('Title'), ['class' => 'col-lg-2 control-label required']) }}
                    
                            <div class="col-lg-10">
                                {{ Form::text('title', $mainData->title, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->
                    
                        <div class="form-group">
                            {{ Form::label('de_name', trans('German Title'), ['class' => 'col-lg-2 control-label required']) }}
                    
                            <div class="col-lg-10">
                                {{ Form::text('de_title', $mainData->de_title, ['class' => 'form-control box-size', 'placeholder' => trans('Enter German Title'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->
                        
                         <div class="form-group">
                            {{ Form::label('title', trans('Text'), ['class' => 'col-lg-2 control-label required']) }}
                    
                            <div class="col-lg-10">
                                {{ Form::text('description', $mainData->description, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->
                    
                        <div class="form-group">
                            {{ Form::label('de_name', trans('German Text'), ['class' => 'col-lg-2 control-label required']) }}
                    
                            <div class="col-lg-10">
                                {{ Form::text('de_description', $mainData->de_description, ['class' => 'form-control box-size', 'placeholder' => trans('Enter German Text'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->
                    </div>
                    <div class="edit-form-btn">
                    {{ Form::submit(trans('Update'), ['class' => 'btn btn-primary btn-md']) }}
                    <div class="clearfix"></div>
                </div>
            </div>
            </div>
        </div>
    </div>
    {{ Form::close() }}
@endsection

@section('after-scripts')
    {{-- For DataTables --}}
    {{ Html::script(mix('js/dataTable.js')) }}

    <script>
        
            $('#faqs-table').dataTable();
        
    </script>
@endsection