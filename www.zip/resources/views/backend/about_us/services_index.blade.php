@extends ('backend.layouts.app')

@section ('title', trans('Services'))

@section('page-header')
    <h1>{{ trans('Services') }}</h1>
@endsection

@section('content')
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title">{{ trans('Services') }}</h3>

            <div class="box-tools pull-right">
                @include('backend.products.partials.header-buttons')
            </div>
        </div><!-- /.box-header -->

        <div class="box-body">
            <div class="table-responsive data-table-wrapper">
                <table id="faqs-table" class="table table-condensed table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Title</th>
                            <th>German Title</th>
                            <th>{{ trans('Created At') }}</th>
                            <th>{{ trans('labels.general.actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(isset($data) && !empty($data))
                            @foreach($data as $k=>$v)
                                <tr>
                                    <td>{!! $k+1 !!}</td>
                                    <td>{!! $v->title !!}</td>
                                    <td>{!! $v->de_title !!}</td>
                                    
                                    <td>{!! date('d M-Y',strtotime($v->created_at)) !!}</td>
                                    <td>
                                        <div class="btn-group action-btn">
                                            <a class="btn btn-default btn-flat" href="{!! URL::to('admin/about-us/services/edit'.'/'.$v->id) !!}">
                                                <i data-toggle="tooltip" data-placement="top" title="" class="fa fa-pencil" data-original-title="Edit"></i>
                                            </a>
                                            
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div><!--table-responsive-->
        </div><!-- /.box-body -->
    </div><!--box-->

@endsection

@section('after-scripts')
    {{-- For DataTables --}}
    {{ Html::script(mix('js/dataTable.js')) }}

    <script>
        
            $('#faqs-table').dataTable();
        
    </script>
@endsection