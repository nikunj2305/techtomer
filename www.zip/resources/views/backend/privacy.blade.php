@extends ('backend.layouts.app')

@section ('title', trans('Privacy Page') . ' | ' . trans('Privacy'))

@section('page-header')
    <h1>
        {{ trans('Privacy') }}
        <small>{{ trans('Update Data') }}</small>
    </h1>
@endsection

@section('content')
    {{ Form::open(['route' => 'admin.privacy.update', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-faq', 'files' => true]) }}

        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">{{ trans('Update Privacy') }}</h3>

                <div class="box-tools pull-right">
                    
                </div><!--box-tools pull-right-->
            </div><!-- /.box-header -->

            {{-- Including Form blade file --}}
            <div class="box-body">
                <div class="form-group">
                    <div class="box-body">

                        <div class="form-group">
                            {{ Form::label('name', trans('Name'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('title', $data->title, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Product Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_name', trans('Germany Name'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('de_title', $data->de_title, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Product Germany Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->
                        
                        <div class="form-group">
                            {{ Form::label('description', trans('Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('description', $data->description, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Description'), 'required' => 'required', 'id' => 'editor']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_description', trans('Germany Description'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::textarea('de_description', $data->de_description, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Germany Description'), 'required' => 'required', 'id' => 'editor1']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                    
                    </div>
                    </div>
                    <div class="edit-form-btn">
                    {{ Form::submit(trans('Update'), ['class' => 'btn btn-primary btn-md']) }}
                    <div class="clearfix"></div>
                </div>
            </div>
        </div><!--box-->
    </div>
    {{ Form::close() }}
@endsection

@section('after-scripts')
    <script src="https://cdn.ckeditor.com/4.15.0/full/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('editor',{
            baseFloatZIndex: 10005
        });

        CKEDITOR.replace('editor1',{
            baseFloatZIndex: 10005
        });
    </script>
@endsection