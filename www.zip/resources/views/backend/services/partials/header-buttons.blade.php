
<div class="btn-group">
  <button type="button" class="btn btn-primary btn-flat dropdown-toggle" data-toggle="dropdown">Action
    <span class="caret"></span>
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <ul class="dropdown-menu" role="menu">
    
      <li><a href="{{route('admin.service.list')}}"><i class="fa fa-list-ul"></i> {{trans('All Service')}}</a></li>
    	<li><a href="{{route('admin.service.create')}}"><i class="fa fa-plus"></i> {{trans('Create Service')}}</a></li>
  </ul>
</div>

<div class="clearfix"></div>