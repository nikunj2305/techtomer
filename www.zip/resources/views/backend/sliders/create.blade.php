@extends ('backend.layouts.app')

@section ('title', trans('Slider Management') . ' | ' . trans('Create Slider'))

@section('page-header')
    <h1>
        {{ trans('Slider Management') }}
        <small>{{ trans('Create New Slider') }}</small>
    </h1>
@endsection

@section('content')
    {{ Form::open(['route' => 'admin.slider.create.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-faq', 'files' => true]) }}

        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">{{ trans('Create Slider') }}</h3>

                <div class="box-tools pull-right">
                    @include('backend.sliders.partials.header-buttons')
                </div><!--box-tools pull-right-->
            </div><!-- /.box-header -->

            {{-- Including Form blade file --}}
            <div class="box-body">
                <div class="form-group">
                    <div class="box-body">

                        <div class="form-group">
                            {{ Form::label('name', trans('Text1'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('name', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Slider text1'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('text2', trans('Text2'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('text2', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Slider text2'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('text3', trans('Text3'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('text3', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Slider text3'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_name', trans('Germany Text1'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('de_name', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Slider Germany Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_text2', trans('Germany Text2'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('de_text2', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Slider Germany text2'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('de_text3', trans('Germany Text3'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::text('de_text3', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Slider Germany text3'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('image', trans('IMAGE'), ['class' => 'col-lg-2 control-label required']) }}

                            <div class="col-lg-10">
                                {{ Form::file('image', null, ['class' => 'form-control box-size', 'placeholder' => trans('Enter Subject Name'), 'required' => 'required']) }}
                            </div><!--col-lg-10-->
                        </div><!--form control-->

                        <div class="form-group">
                            {{ Form::label('status', trans('STATUS'), ['class' => 'col-lg-2 control-label']) }}

                            <div class="col-lg-10">
                                <div class="control-group">
                                    <label class="control control--checkbox">
                                        
                                            {{ Form::checkbox('is_active', 1, true) }}
                                        
                                        <div class="control__indicator"></div>
                                    </label>
                                </div>
                            </div><!--col-lg-3-->
                        </div><!--form control-->
                    </div>
                    </div>
                    <div class="edit-form-btn">
                    {{ link_to_route('admin.slider.list', trans('buttons.general.cancel'), [], ['class' => 'btn btn-danger btn-md']) }}
                    
                    {{ Form::submit(trans('buttons.general.crud.create'), ['class' => 'btn btn-primary btn-md']) }}
                    <div class="clearfix"></div>
                </div>
            </div>
        </div><!--box-->
    </div>
    {{ Form::close() }}
@endsection

@section('after-scripts')
    
@endsection