
<div class="btn-group">
  <button type="button" class="btn btn-primary btn-flat dropdown-toggle" data-toggle="dropdown">Action
    <span class="caret"></span>
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <ul class="dropdown-menu" role="menu">
    
      <li><a href="{{route('admin.slider.list')}}"><i class="fa fa-list-ul"></i> {{trans('All Slider')}}</a></li>
    	<li><a href="{{route('admin.slider.create')}}"><i class="fa fa-plus"></i> {{trans('Create Slider')}}</a></li>
  </ul>
</div>

<div class="clearfix"></div>