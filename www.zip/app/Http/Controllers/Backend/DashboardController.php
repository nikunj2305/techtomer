<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Access\Permission\Permission;
use App\Models\Access\Role\Role;
use App\Models\Access\User\User;
use App\Models\Settings\Setting;
use Illuminate\Http\Request;
use DB, Image;
use Illuminate\Support\Facades\Input;

/**
 * Class DashboardController.
 */
class DashboardController extends Controller
{
    /**
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $settingData = Setting::first();
        $google_analytics = $settingData->google_analytics;

        return view('backend.dashboard', compact('google_analytics', $google_analytics));
    }

    /**
     * Used to display form for edit profile.
     *
     * @return view
     */
    public function editProfile(Request $request)
    {
        return view('backend.access.users.profile-edit')
            ->withLoggedInUser(access()->user());
    }

    /**
     * Used to update profile.
     *
     * @return view
     */
    public function updateProfile(Request $request)
    {
        $input = $request->all();
        $userId = access()->user()->id;
        $user = User::find($userId);
        $user->first_name = $input['first_name'];
        $user->last_name = $input['last_name'];
        $user->updated_by = access()->user()->id;

        if ($user->save()) {
            return redirect()->route('admin.profile.edit')
                ->withFlashSuccess(trans('labels.backend.profile_updated'));
        }
    }

    /**
     * This function is used to get permissions details by role.
     *
     * @param Request $request
     */
    public function getPermissionByRole(Request $request)
    {
        if ($request->ajax()) {
            $role_id = $request->get('role_id');
            $rsRolePermissions = Role::where('id', $role_id)->first();
            $rolePermissions = $rsRolePermissions->permissions->pluck('display_name', 'id')->all();
            $permissions = Permission::pluck('display_name', 'id')->all();
            ksort($rolePermissions);
            ksort($permissions);
            $results['permissions'] = $permissions;
            $results['rolePermissions'] = $rolePermissions;
            $results['allPermissions'] = $rsRolePermissions->all;
            echo json_encode($results);
            die;
        }
    }
    
    public function getPrivacy()
    {
        $data = DB::table('pages')->where('page_slug', 'privacy')->first();
        return view('backend.privacy', compact('data'));
    }

    public function postPrivacy(Request $request)
    {
        $con = array('title' => $request->title, 'de_title' =>$request->de_title, 'description' => $request->description, 'de_description' =>$request->de_description);
        DB::table('pages')->where('page_slug', 'privacy')->update($con);
        return redirect()->back()->withFlashSuccess(trans('Update successfully'));
    }
    
    public function getCookie()
    {
        $data = DB::table('pages')->where('page_slug', 'cookie')->first();
        return view('backend.cookie', compact('data'));
    }

    public function postCookie(Request $request)
    {
        $con = array('title' => $request->title, 'de_title' =>$request->de_title, 'description' => $request->description, 'de_description' =>$request->de_description);
        DB::table('pages')->where('page_slug', 'cookie')->update($con);
        return redirect()->back()->withFlashSuccess(trans('Update successfully'));
    }

    public function getCustomise()
    {
        $data = DB::table('pages')->where('page_slug', 'customise')->first();
        return view('backend.customise', compact('data'));
    }

    public function postCustomise(Request $request)
    {
        $con = array('title' => $request->title, 'de_title' =>$request->de_title, 'description' => $request->description, 'de_description' =>$request->de_description);
        DB::table('pages')->where('page_slug', 'customise')->update($con);
        return redirect()->back()->withFlashSuccess(trans('Update successfully'));
    }

    public function getDisclaimer()
    {
        $data = DB::table('pages')->where('page_slug', 'disclaimer')->first();
        return view('backend.disclaimer', compact('data'));
    }

    public function postDisclaimer(Request $request)
    {
        $con = array('title' => $request->title, 'de_title' =>$request->de_title, 'description' => $request->description, 'de_description' =>$request->de_description);
        DB::table('pages')->where('page_slug', 'disclaimer')->update($con);
        return redirect()->back()->withFlashSuccess(trans('Update successfully'));
    }

    /*Product Management Start*/
        public function getProduct()
        {
            $data = DB::table('products')->get()->toArray();
            return view('backend.products.index', compact('data'));
        }

        public function getProductCreate()
        {
            return view('backend.products.create');
        }

        public function postProductCreate(Request $request)
        {
            $data = DB::table('products')->where('name', $request->name)->first();
            if(!empty($data)){
                   return redirect()->back()->withFlashDanger(trans('State Name already exist'));    
            }
            $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/product/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            //$con = array('name' =>$request->name, 'slug' =>str_slug($request->name), 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1, 'description' => $request->description);
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1, 'description' => $request->description, 'de_description' => $request->de_description);

            DB::table('products')->insert($con);
            return redirect()->route('admin.product.list')->withFlashSuccess(trans('Product Save successfully'));        
        }

        public function getProductStatus($id=NULL, $type=NULL)
        {
            DB::table('products')->where('id', $id)->update(['is_active' => $type]);
            return redirect()->route('admin.product.list')->withFlashSuccess(trans('Status change successfully'));
        }

        public function getProductDelete($id=NULL)
        {
            DB::table('products')->where('id', $id)->delete();
            return redirect()->route('admin.product.list')->withFlashSuccess(trans('Delete successfully'));
        }

        public function getProductEdit($id=NULL)
        {
            $data = DB::table('products')->where('id', $id)->first();
            return view('backend.products.edit', compact('data'));
        }

        public function postProductEdit(Request $request)
        {
            $data = DB::table('products')->where('id', '!=', $request->id)->where('name', $request->name)->first();
            if(!empty($data)){
                return redirect()->back()->withFlashDanger(trans('State Name already exist'));    
            }

            $newfilename1 = '';
            $altTag = '';
            $path = 'public/img/product/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            else{
                $newfilename1 = $request->old_image;
                $altTag = $request->old_tag;
            }
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1, 'description' => $request->description, 'de_description' => $request->de_description);
            DB::table('products')->where('id', $request->id)->update($con);
            return redirect()->route('admin.product.list')->withFlashSuccess(trans('State Update successfully'));
        }
    /*Product Management End*/
    
    public function aboutUsEdit($slug='')
	{
	    $result = '';
	    if($slug == 'who_we_are'){
	        $result = DB::table('who_we_are')->where('is_active', 1)->first();
	        return view('backend.about_us.who_we_are', compact('result'));
	    }elseif($slug == 'services'){
	        $result = DB::table('blocks')->where('slug','service')->where('is_active', 1)->get();
	        return view('backend.about_us.services', compact('result'));
	    }elseif($slug == 'why_choose_us'){
	        $result = DB::table("why_choose_us")->where('is_active',1)->select('why_choose_us.*',DB::raw("null as blocks"))->first();
			if(!empty($result)){
			    $choose_data =DB::table("why_choose_us_blocks")->select('text','de_text')->get();
			    if(!empty($choose_data)){
			        $result->blocks=$choose_data;
			    }else{
			        $result->blocks=[];
			    }
			    
			}
			return view('backend.about_us.why_choose_us', compact('result'));
	    }elseif($slug == 'teams'){
	        $result = DB::table('blocks')->where('slug','team')->where('is_active', 1)->select('blocks.*',DB::raw("null as agents"))->first();
			if(!empty($result)){
			    $allAgent = DB::table("teams")->where('is_active', 1)->get();
			    if(!empty($allAgent)){
			        $result->agents = $allAgent;
			    }else{
			         $result->agents = [];
			    }
			}
			return view('backend.about_us.team', compact('result'));
	    }else{
	        return redirect()->back()->withFlashDanger(trans('Invalid type.')); 
	    }
	     
	}
	
	public function aboutUsUpdate(Request $request)
	{
	    $slug = $request->slug;
	    
	    if($slug == 'who_we_are'){
	        $updateArr = ['heading'=>$request->heading, 'de_heading'=>$request->de_heading,'title'=>$request->title, 'de_title'=>$request->de_title,'description'=>$request->description, 'de_description'=>$request->de_description];
	        $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/about_us/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
                $updateArr['image']=$newfilename1;
            }
	        DB::table('who_we_are')->where('id', 1)->update($updateArr);
	        return redirect()->back()->withFlashSuccess(trans('Who We Are updated successfully.'));
	    }elseif($slug == 'services'){
	        $find = DB::table('blocks')->where('slug','service')->where('id',$request->id)->where('is_active', 1)->first();
	        if(empty($find)){
	            return redirect()->back()->withFlashDanger(trans('Data not found.'));
	        }
	        $updateArr = ['title'=>$request->title, 'de_title'=>$request->de_title,'description'=>$request->description, 'de_description'=>$request->de_description];
	        $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/about_us/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
                $updateArr['image']=$newfilename1;
            }
	        
	        $result = DB::table('blocks')->where('slug','service')->where('id',$request->id)->update($updateArr);
	        return redirect()->back()->withFlashSuccess(trans('Services updated successfully.'));
	    }elseif($slug == 'why_choose_us'){
	        $updateArr = ['video_url'=>$request->video_url,'heading'=>$request->heading, 'de_heading'=>$request->de_heading,'title'=>$request->title, 'de_title'=>$request->de_title,'description'=>$request->description, 'de_description'=>$request->de_description];
	        
	        $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/about_us/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
                $updateArr['image']=$newfilename1;
            }
	        DB::table("why_choose_us")->where('id',1)->update($updateArr);
	        $blocks = $request->blocks;
			if(!empty($blocks) && count($blocks)>0){
			    DB::table("why_choose_us_blocks")->delete();
			    foreach($blocks as $key => $block){
			        $arr = ["choose_us_id"=>1,'text'=>$block['text'],'de_text'=>$block['de_text'],'created_at'=>date("Y-m-d H:i:s"),'updated_at'=>date("Y-m-d H:i:s")];
			        DB::table("why_choose_us_blocks")->insert($arr);
			    }
			    
			}else{
			    DB::table("why_choose_us_blocks")->delete();
			}
			return redirect()->back()->withFlashSuccess(trans('Why choose us updated successfully.'));
	    }elseif($slug == 'teams'){
	        $result = DB::table('blocks')->where('slug','team')->where('id', 4)->first();
	        if(empty($result)){
	             return redirect()->back()->withFlashDanger(trans('Data not found.'));
	        }
		    $updateArr = ['title'=>$request->title, 'de_title'=>$request->de_title,'description'=>$request->description, 'de_description'=>$request->de_description];
	        
	        $result = DB::table('blocks')->where('slug','team')->where('id',4)->update($updateArr);
	        return redirect()->back()->withFlashSuccess(trans('Team data updated successfully.'));
	    }elseif($slug == 'teams_block'){
		    $blocks = DB::table("teams")->where('id', $request->id)->first();
		    if(!empty($blocks)){
		        $updateArr = ['name'=>$request->name, 'de_name'=>$request->de_name,'designation'=>$request->designation, 'de_designation'=>$request->de_designation];
    	        $newfilename1 = '';
                $altTag = '';
                $path = '/public/img/about_us/';
                if( $file =Input::file('image') ){
                    $originalImage= $file;
                    $imageName =  $originalImage->getClientOriginalName(); 
                    $img1 = explode('.', $imageName);
                    $altTag= isset($img1[0]) ? $img1[0] : $img1;
    
                    $thumbnailImage = Image::make($originalImage);
                    $thumbnailPath = base_path().$path;
                    $size = $thumbnailImage->filesize();
                    $width = $thumbnailImage->width();
                    $height = $thumbnailImage->height();
                    $thumbnailImage->fit($width,$height);
                    $newfilename1 = time().$originalImage->getClientOriginalName();
                    $thumbnailImage->save($thumbnailPath.$newfilename1);
                    $updateArr['image']=$newfilename1;
                }
                DB::table("teams")->where('id', $request->id)->update($updateArr);
                return redirect()->back()->withFlashSuccess(trans("Client's data updated successfully."));
		    }else{
		         return redirect()->back()->withFlashDanger(trans('Data not found.'));
		    }
	    }else{
	        return redirect()->back()->withFlashDanger(trans('Invalid type.')); 
	    }
	}
	
	public function servicesList(){
	    $data = DB::table('blocks')->where('slug','service')->where('is_active', 1)->get();
	    return view('backend.about_us.services_index', compact('data'));
	}
	public function servicesEdit($id=NULL){
	    $data = DB::table('blocks')->where('slug','service')->where('id', $id)->first();
	    return view('backend.about_us.services', compact('data'));
	}
	
	
	public function teamList(){
	    $data =DB::table('teams')->where('is_active',1)->get();
	    $mainData = DB::table('blocks')->where('slug','team')->where('id', 4)->first();
	    
	    return view('backend.about_us.team_index', compact('data','mainData'));
	}
	public function teamEdit($id=NULL){
	    $data = DB::table('teams')->where('id', $id)->first();
	    return view('backend.about_us.team', compact('data'));
	}

    /*Slider Management Start*/
        public function getSlider()
        {
            $data = DB::table('sliders')->get()->toArray();
            return view('backend.sliders.index', compact('data'));
        }

        public function getSliderCreate()
        {
            return view('backend.sliders.create');
        }

        public function postSliderCreate(Request $request)
        {
            $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/slider/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            //$con = array('name' =>$request->name, 'slug' =>str_slug($request->name), 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1, 'description' => $request->description);
            $con = array('name' =>$request->name, 'text2' =>$request->text2, 'text3' =>$request->text3, 'de_name' =>$request->de_name, 'de_text2' =>$request->de_text2, 'de_text3' =>$request->de_text3, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);

            DB::table('sliders')->insert($con);
            return redirect()->route('admin.slider.list')->withFlashSuccess(trans('Slider Save successfully'));        
        }

        public function getSliderStatus($id=NULL, $type=NULL)
        {
            DB::table('sliders')->where('id', $id)->update(['is_active' => $type]);
            return redirect()->route('admin.slider.list')->withFlashSuccess(trans('Status change successfully'));
        }

        public function getSliderDelete($id=NULL)
        {
            DB::table('sliders')->where('id', $id)->delete();
            return redirect()->route('admin.slider.list')->withFlashSuccess(trans('Delete successfully'));
        }

        public function getSliderEdit($id=NULL)
        {
            $data = DB::table('sliders')->where('id', $id)->first();
            return view('backend.sliders.edit', compact('data'));
        }

        public function postSliderEdit(Request $request)
        {
            $newfilename1 = '';
            $altTag = '';
            $path = 'public/img/slider/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            else{
                $newfilename1 = $request->old_image;
                //$altTag = $request->old_tag;
            }
            //$con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);
            $con = array('name' =>$request->name, 'text2' =>$request->text2, 'text3' =>$request->text3, 'de_name' =>$request->de_name, 'de_text2' =>$request->de_text2, 'de_text3' =>$request->de_text3, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);
            DB::table('sliders')->where('id', $request->id)->update($con);
            return redirect()->route('admin.slider.list')->withFlashSuccess(trans('Update successfully'));
        }
    /*Slider Management End*/

    /*Review Management Start*/
        public function getReview()
        {
            $data = DB::table('reviews')->get()->toArray();
            return view('backend.reviews.index', compact('data'));
        }

        public function getReviewCreate()
        {
            return view('backend.reviews.create');
        }

        public function postReviewCreate(Request $request)
        {
            $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/review/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            //$con = array('name' =>$request->name, 'slug' =>str_slug($request->name), 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1, 'description' => $request->description);
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'review' =>$request->review, 'de_review' =>$request->de_review, 'company' =>$request->company, 'de_company' =>$request->de_company, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);

            DB::table('reviews')->insert($con);
            return redirect()->route('admin.review.list')->withFlashSuccess(trans('Review Save successfully'));        
        }

        public function getReviewStatus($id=NULL, $type=NULL)
        {
            DB::table('reviews')->where('id', $id)->update(['is_active' => $type]);
            return redirect()->route('admin.review.list')->withFlashSuccess(trans('Status change successfully'));
        }

        public function getReviewDelete($id=NULL)
        {
            DB::table('reviews')->where('id', $id)->delete();
            return redirect()->route('admin.review.list')->withFlashSuccess(trans('Delete successfully'));
        }

        public function getReviewEdit($id=NULL)
        {
            $data = DB::table('reviews')->where('id', $id)->first();
            return view('backend.reviews.edit', compact('data'));
        }

        public function postReviewEdit(Request $request)
        {
            $newfilename1 = '';
            $altTag = '';
            $path = 'public/img/review/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            else{
                $newfilename1 = $request->old_image;
                //$altTag = $request->old_tag;
            }
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'review' =>$request->review, 'de_review' =>$request->de_review, 'company' =>$request->company, 'de_company' =>$request->de_company, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);
            //$con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);
            DB::table('reviews')->where('id', $request->id)->update($con);
            return redirect()->route('admin.review.list')->withFlashSuccess(trans('Update successfully'));
        }
    /*Review Management End*/

    /*Career Management Start*/
        public function getCareer()
        {
            $data = DB::table('careers')->get()->toArray();
            return view('backend.careers.index', compact('data'));
        }

        public function getCareerCreate()
        {
            return view('backend.careers.create');
        }

        public function postCareerCreate(Request $request)
        {
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'sort_description' => $request->sort_description, 'de_sort_description' => $request->de_sort_description, 'description' => $request->description, 'de_description' => $request->de_description, 'vacancy' => $request->vacancy, 'work_status' => $request->work_status, 'exp' => $request->exp, 'technology' => $request->technology, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No');
            DB::table('careers')->insert($con);
            return redirect()->route('admin.career.list')->withFlashSuccess(trans('Post Save successfully'));        
        }

        public function getCareerStatus($id=NULL, $type=NULL)
        {
            DB::table('careers')->where('id', $id)->update(['is_active' => $type]);
            return redirect()->route('admin.career.list')->withFlashSuccess(trans('Status change successfully'));
        }

        public function getCareerDelete($id=NULL)
        {
            DB::table('careers')->where('id', $id)->delete();
            return redirect()->route('admin.career.list')->withFlashSuccess(trans('Delete successfully'));
        }

        public function getCareerEdit($id=NULL)
        {
            $data = DB::table('careers')->where('id', $id)->first();
            return view('backend.careers.edit', compact('data'));
        }

        public function postCareerEdit(Request $request)
        {
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'sort_description' => $request->sort_description, 'de_sort_description' => $request->de_sort_description, 'description' => $request->description, 'de_description' => $request->de_description, 'vacancy' => $request->vacancy, 'work_status' => $request->work_status, 'exp' => $request->exp, 'technology' => $request->technology, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No');
            DB::table('careers')->where('id', $request->id)->update($con);
            return redirect()->route('admin.career.list')->withFlashSuccess(trans('Post Update successfully'));
        }
    /*Career Management End*/

    /*Service Management Start*/
        public function getService()
        {
            $data = DB::table('services')->get()->toArray();
            return view('backend.services.index', compact('data'));
        }

        public function getServiceCreate()
        {
            return view('backend.services.create');
        }

        public function postServiceCreate(Request $request)
        {
            $data = DB::table('services')->where('title', $request->title)->first();
            if(!empty($data)){
                   return redirect()->back()->withFlashDanger(trans('Service Name already exist'));    
            }
            $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/product/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            $con = array('slug' => str_slug($request->title),'title' =>$request->title, 'de_title' =>$request->de_title, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1, 'description' => $request->description, 'de_description' => $request->de_description, 'home' => isset($request->home) && $request->home == 'Yes' ? 'Yes': 'No', 'about' => isset($request->about) && $request->about == 'Yes' ? 'Yes': 'No', 'top' => isset($request->top) && $request->top == 'Yes' ? 'Yes': 'No', 'buttom' => isset($request->buttom) && $request->buttom == 'Yes' ? 'Yes': 'No');

            DB::table('services')->insert($con);
            return redirect()->route('admin.service.list')->withFlashSuccess(trans('Service Save successfully'));        
        }

        public function getServiceStatus($id=NULL, $type=NULL)
        {
            DB::table('services')->where('id', $id)->update(['is_active' => $type]);
            return redirect()->back()->withFlashSuccess(trans('Status change successfully'));
        }

        public function getServiceDelete($id=NULL)
        {
            DB::table('services')->where('id', $id)->delete();
            return redirect()->back()->withFlashSuccess(trans('Delete successfully'));
        }

        public function getServiceEdit($id=NULL)
        {
            $data = DB::table('services')->where('id', $id)->first();
            return view('backend.services.edit', compact('data'));
        }

        public function postServiceEdit(Request $request)
        {
            $data = DB::table('services')->where('id', '!=', $request->id)->where('title', $request->title)->first();
            if(!empty($data)){
                return redirect()->back()->withFlashDanger(trans('Service Name already exist'));    
            }

            $newfilename1 = '';
            $altTag = '';
            $path = 'public/img/product/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            else{
                $newfilename1 = $request->old_image;
                //$altTag = $request->old_tag;
            }
            $con = array('title' =>$request->title, 'de_title' =>$request->de_title, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1, 'description' => $request->description, 'de_description' => $request->de_description, 'home' => isset($request->home) && $request->home == 'Yes' ? 'Yes': 'No', 'about' => isset($request->about) && $request->about == 'Yes' ? 'Yes': 'No', 'top' => isset($request->top) && $request->top == 'Yes' ? 'Yes': 'No', 'buttom' => isset($request->buttom) && $request->buttom == 'Yes' ? 'Yes': 'No');
            DB::table('services')->where('id', $request->id)->update($con);
            //echo "<pre>"; print_r($request->all()); exit;
            return redirect()->route('admin.service.list')->withFlashSuccess(trans('Service Update successfully'));
        }
    /*Product Management End*/

    /*Software Management Start*/
        public function getSoftware()
        {
            $data = DB::table('softwares')->get()->toArray();
            return view('backend.softwares.index', compact('data'));
        }

        public function getSoftwareCreate()
        {
            return view('backend.softwares.create');
        }

        public function postSoftwareCreate(Request $request)
        {
            $newfilename1 = '';
            $altTag = '';
            $path = '/public/img/slider/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);
            DB::table('softwares')->insert($con);
            return redirect()->route('admin.software.list')->withFlashSuccess(trans('Software Save successfully'));        
        }

        public function getSoftwareStatus($id=NULL, $type=NULL)
        {
            DB::table('softwares')->where('id', $id)->update(['is_active' => $type]);
            return redirect()->route('admin.software.list')->withFlashSuccess(trans('Status change successfully'));
        }

        public function getSoftwareDelete($id=NULL)
        {
            DB::table('softwares')->where('id', $id)->delete();
            return redirect()->route('admin.software.list')->withFlashSuccess(trans('Delete successfully'));
        }

        public function getSoftwareEdit($id=NULL)
        {
            $data = DB::table('softwares')->where('id', $id)->first();
            return view('backend.softwares.edit', compact('data'));
        }

        public function postSoftwareEdit(Request $request)
        {
            $newfilename1 = '';
            $altTag = '';
            $path = 'public/img/slider/';
            if( $file =Input::file('image') ){
                $originalImage= $file;
                $imageName =  $originalImage->getClientOriginalName(); 
                $img1 = explode('.', $imageName);
                $altTag= isset($img1[0]) ? $img1[0] : $img1;

                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = base_path().$path;
                $size = $thumbnailImage->filesize();
                $width = $thumbnailImage->width();
                $height = $thumbnailImage->height();
                /*if($width > 600){
                    $width = 600;
                }
                if($height > 380){
                    $height = 380;
                }*/
                $thumbnailImage->fit($width,$height);
                $newfilename1 = time().$originalImage->getClientOriginalName();
                $thumbnailImage->save($thumbnailPath.$newfilename1);
            }
            else{
                $newfilename1 = $request->old_image;
                //$altTag = $request->old_tag;
            }
            //$con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);
            $con = array('name' =>$request->name, 'de_name' =>$request->de_name, 'is_active' => isset($request->is_active) && $request->is_active ==1 ? 'Yes': 'No', 'image' => $newfilename1);
            DB::table('softwares')->where('id', $request->id)->update($con);
            return redirect()->route('admin.software.list')->withFlashSuccess(trans('Update successfully'));
        }
    /*Slider Management End*/
}
