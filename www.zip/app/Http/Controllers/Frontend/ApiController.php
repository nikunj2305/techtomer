<?php
namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use DB, Mail, Redirect, Response, Auth, Session;
use Illuminate\Sublogport\Facades\Input;
use Illuminate\Support\Facades\Request;
use Hash,Validator, App;
use URL;
use File;
use Image;
use Carbon\Carbon;

/**
 * Class FrontendController
 *@package App\Https\Controllers
*/

class ApiController extends Controller
{
	public function checkToken($access_token,$user_id='',$session_key='')
	{
		$token=12345;//env('ACCESS_TOKEN');
		if($access_token!=$token){
			$resultArray['status']='0';
			$resultArray['message']=trans('invalid_token');
			return $resultArray; die;
		} else {
			$resultArray['status']='1';
			$resultArray['message']=trans('valid token');
			return $resultArray; die;
		}
	}

	public function postPage()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$slug = isset($_REQUEST['page_name']) && !empty($_REQUEST['page_name']) ? trim($_REQUEST['page_name']) : '' ;
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'en'){
				$data = DB::table('pages')->where('page_slug', $slug)->select('title', 'description')->first();
			}else{
				$data = DB::table('pages')->where('page_slug', $slug)->select('de_title as title', 'de_description as description')->first();
			}
			if(!empty($data)){
				$mess='Successfully';
				$resultArray['status']='1';
				$resultArray['message']=$mess;
				$resultArray['data'] = $data;
			}else{
				$mess='data not found !';
				$resultArray['status']='0';
				$resultArray['message']=$mess;
			}
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}

	public function postProduct()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'de'){
				$data = DB::table('products')->where('is_active', 'Yes')->select('de_name as name', 'de_description as description','image')->get();
			}else{
				$data = DB::table('products')->where('is_active', 'Yes')->select('name', 'description','image')->get();
			}
			if(!empty($data)){
				$mess='Successfully';
				$resultArray['status']='1';
				$resultArray['message']=$mess;
				$resultArray['image_url']=URL::to("img/product/");
				$resultArray['data'] = $data;
			}else{
				$mess='data not found !';
				$resultArray['status']='0';
				$resultArray['message']=$mess;
			}
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}
	
	public function aboutUs()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'de'){
				$whoWeAre = DB::table('who_we_are')->where('is_active', 1)->select('de_heading as heading', 'de_title as title','de_description as description','image')->first();
				$serviceBlock = DB::table('blocks')->where('slug','service')->where('is_active', 1)->select('de_title as title','de_description as description','image')->get();
				$whyChooseUs = DB::table("why_choose_us")->where('is_active',1)->select('de_heading as heading', 'de_title as title','de_description as description','image','video_url',DB::raw("null as blocks"))->first();
				if(!empty($whyChooseUs)){
				    $choose_data =DB::table("why_choose_us_blocks")->select('de_text as text')->get();
				    if(!empty($choose_data)){
				        $whyChooseUs->blocks=$choose_data;
				    }else{
				        $whyChooseUs->blocks=[];
				    }
				    
				}
				$teamData = DB::table('blocks')->where('slug','team')->where('is_active', 1)->select('de_title as title','de_description as description',DB::raw("null as agents"))->first();
				if(!empty($teamData)){
				    $allAgent = DB::table("teams")->where('is_active', 1)->select('de_name as name','de_designation as designation','image')->get();
				    if(!empty($allAgent)){
				        $teamData->agents = $allAgent;
				    }else{
				         $teamData->agents = [];
				    }
				}
			}else{
				$whoWeAre = DB::table('who_we_are')->where('is_active', 1)->select('heading', 'title','description','image')->first();
				$serviceBlock = DB::table('blocks')->where('slug','service')->where('is_active', 1)->select('title','description','image')->get();
				$whyChooseUs = DB::table("why_choose_us")->where('is_active',1)->select('heading', 'title','description','image','video_url',DB::raw("null as blocks"))->first();
				if(!empty($whyChooseUs)){
				    $choose_data =DB::table("why_choose_us_blocks")->select('text')->get();
				    if(!empty($choose_data)){
				        $whyChooseUs->blocks=$choose_data;
				    }else{
				        $whyChooseUs->blocks=[];
				    }
				    
				}
				$teamData = DB::table('blocks')->where('slug','team')->where('is_active', 1)->select('title','description',DB::raw("null as agents"))->first();
				if(!empty($teamData)){
				    $allAgent = DB::table("teams")->where('is_active', 1)->select('name','designation','image')->get();
				    if(!empty($allAgent)){
				        $teamData->agents = $allAgent;
				    }else{
				         $teamData->agents = [];
				    }
				}
			}
			$data = ['who_we_are'=>$whoWeAre, 'services'=>$serviceBlock, 'why_choose_us'=>$whyChooseUs, 'team'=>$teamData];
			if(!empty($data)){
				$mess='Successfully';
				$resultArray['status']='1';
				$resultArray['message']=$mess;
				$resultArray['image_url']=URL::to("img/about_us/");
				$resultArray['data'] = $data;
			}else{
				$mess='data not found !';
				$resultArray['status']='0';
				$resultArray['message']=$mess;
			}
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}

	public function postHome()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'en'){
				$image = DB::table('sliders')->select('name', 'text2', 'text3', 'image')->get()->toArray();
				$review = DB::table('reviews')->select('name', 'company', 'review', 'image')->get()->toArray();
				$software = DB::table('softwares')->select('name', 'image')->get()->toArray();
			}else{
				$image = DB::table('sliders')->select('de_name as name', 'de_text2 as text2', 'de_text3 as text3', 'image')->get()->toArray();
				$review = DB::table('reviews')->select('de_name as name', 'de_company as company', 'de_review as review', 'image')->get()->toArray();
				$software = DB::table('softwares')->select('de_name as name', 'image')->get()->toArray();
			}
			$mess='Successfully';
			$resultArray['status']='1';
			$resultArray['message']=$mess;
			$resultArray['slider_image_url']=URL::to("img/slider/");
			$resultArray['review_image_url']=URL::to("img/review/");
			$resultArray['software_image_url']=URL::to("img/slider/");
			$resultArray['data']['slider'] = $image;
			$resultArray['data']['rivew'] = $review;
			$resultArray['data']['software'] = $software;
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}

	public function postCareer()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'en'){
				$image = DB::table('careers')->select('id', 'name', 'sort_description as description', 'vacancy', 'work_status', 'exp', 'technology')->where('is_active', 'yes')->get()->toArray();
			}else{
				$image = DB::table('careers')->select('id', 'de_name as name', 'de_sort_description as description', 'vacancy', 'work_status', 'exp', 'technology')->where('is_active', 'yes')->get()->toArray();
			}
			if(!empty($image)){
				$mess='Successfully';
				$resultArray['status']='1';
				$resultArray['message']=$mess;
				$resultArray['data'] = $image;
			}
			else{
				$mess='data not found !';
				$resultArray['status']='0';
				$resultArray['message']=$mess;				
			}
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}

	public function postCareerDetail()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$id = isset($_REQUEST['id']) && !empty($_REQUEST['id']) ? trim($_REQUEST['id']) : '' ;
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'en'){
				$image = DB::table('careers')->select('id', 'name', 'description', 'vacancy', 'work_status', 'exp', 'technology')->where('id', $id)->first();
			}else{
				$image = DB::table('careers')->select('id', 'de_name as name', 'de_description as description', 'vacancy', 'work_status', 'exp', 'technology')->where('id', $id)->first();
			}
			if(!empty($image)){
				$mess='Successfully';
				$resultArray['status']='1';
				$resultArray['message']=$mess;
				$resultArray['data'] = $image;
			}
			else{
				$mess='data not found !';
				$resultArray['status']='0';
				$resultArray['message']=$mess;				
			}
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}

	public function postService()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'en'){
				$top = DB::table('services')->select('id', 'slug', 'title', 'description', 'image')->where('top', 'Yes')->where('is_active', 'Yes')->get()->toArray();
				$buttom = DB::table('services')->select('id', 'slug', 'title', 'description', 'image')->where('buttom', 'Yes')->where('is_active', 'Yes')->get()->toArray();
			}else{
				$top = DB::table('services')->select('id', 'slug', 'de_title as title', 'de_description as description', 'image')->where('top', 'Yes')->where('is_active', 'Yes')->get()->toArray();
				$buttom = DB::table('services')->select('id', 'slug', 'de_title as title', 'de_description as description', 'image')->where('buttom', 'Yes')->where('is_active', 'Yes')->get()->toArray();
			}
			$mess='Successfully';
			$resultArray['status']='1';
			$resultArray['message']=$mess;
			$resultArray['image_url']=URL::to("img/product/");
			$resultArray['data']['top'] = $top;
			$resultArray['data']['buttom'] = $buttom;
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}

	public function postServiceDetail()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$id = isset($_REQUEST['id']) && !empty($_REQUEST['id']) ? trim($_REQUEST['id']) : '' ;
		$lang = isset($_REQUEST['lang']) && !empty($_REQUEST['lang']) ? trim($_REQUEST['lang']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			if($lang == 'en'){
				$image = DB::table('services')->select('id', 'slug', 'title', 'description', 'image')->where('id', $id)->where('is_active', 'Yes')->get()->toArray();
			}else{
				$image = DB::table('services')->select('id', 'slug', 'de_title as title', 'de_description as description', 'image')->where('id', $id)->where('is_active', 'Yes')->get()->toArray();
			}
			if(!empty($image)){
				$mess='Successfully';
				$resultArray['status']='1';
				$resultArray['message']=$mess;
				$resultArray['image_url']=URL::to("img/product/");
				$resultArray['data'] = $image;
			}
			else{
				$mess='data not found !';
				$resultArray['status']='0';
				$resultArray['message']=$mess;				
			}
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}

	public function postPostJop()
	{
		$access_token = 12345;//Request::header('accesstoken');
		$check_auth = $this->checkToken($access_token);
		$first_name = isset($_REQUEST['first_name']) && !empty($_REQUEST['first_name']) ? trim($_REQUEST['first_name']) : '' ;
		$last_name = isset($_REQUEST['last_name']) && !empty($_REQUEST['last_name']) ? trim($_REQUEST['last_name']) : '' ;
		$number = isset($_REQUEST['number']) && !empty($_REQUEST['number']) ? trim($_REQUEST['number']) : '' ;
		$email = isset($_REQUEST['email']) && !empty($_REQUEST['email']) ? trim($_REQUEST['email']) : '' ;
		$language = isset($_REQUEST['language']) && !empty($_REQUEST['language']) ? trim($_REQUEST['language']) : '' ;
		$street = isset($_REQUEST['street']) && !empty($_REQUEST['street']) ? trim($_REQUEST['street']) : '' ;
		$zip = isset($_REQUEST['zip']) && !empty($_REQUEST['zip']) ? trim($_REQUEST['zip']) : '' ;
		$cover = isset($_REQUEST['cover']) && !empty($_REQUEST['cover']) ? trim($_REQUEST['cover']) : '' ;
		$cv = isset($_REQUEST['cv']) && !empty($_REQUEST['cv']) ? trim($_REQUEST['cv']) : '' ;
		if($check_auth['status']!=1){
			return json_encode($check_auth);
		} else {
			$mess='Apply Successfully';
			$resultArray['status']='1';
			$resultArray['message']=$mess;
			return response()->json($resultArray,JSON_UNESCAPED_UNICODE);exit;
		}
	}
} ?>