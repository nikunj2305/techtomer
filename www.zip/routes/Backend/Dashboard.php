<?php

/**
 * All route names are prefixed with 'admin.'.
 */
Route::get('dashboard', 'DashboardController@index')->name('dashboard');
Route::post('get-permission', 'DashboardController@getPermissionByRole')->name('get.permission');

/*
 * Edit Profile
*/
Route::get('profile/edit', 'DashboardController@editProfile')->name('profile.edit');
Route::patch('profile/update', 'DashboardController@updateProfile')
    ->name('profile.update');
    
Route::get('privacy', 'DashboardController@getPrivacy')->name('privacy');
Route::post('privacy', 'DashboardController@postPrivacy')->name('privacy.update');

Route::get('cookie', 'DashboardController@getCookie')->name('cookie');
Route::post('cookie', 'DashboardController@postCookie')->name('cookie.update');

Route::get('customise', 'DashboardController@getCustomise')->name('customise');
Route::post('customise', 'DashboardController@postCustomise')->name('customise.update');

Route::get('disclaimer', 'DashboardController@getDisclaimer')->name('disclaimer');
Route::post('disclaimer', 'DashboardController@postDisclaimer')->name('disclaimer.update');

/* Product Route Start*/
	Route::get('product', 'DashboardController@getProduct')->name('product.list');
	Route::get('product/create', 'DashboardController@getProductCreate')->name('product.create');
	Route::post('product/create', 'DashboardController@postProductCreate')->name('product.create.store');
	Route::get('product/status/{id}/{type}', 'DashboardController@getProductStatus')->name('product.status');
	Route::get('product/delete/{id}', 'DashboardController@getProductDelete')->name('product.delete');
	Route::get('product/edit/{id}', 'DashboardController@getProductEdit')->name('product.edit');
	Route::post('product/edit', 'DashboardController@postProductEdit')->name('product.edit.update');
/* Product Route End*/
/* About us manage routes starts*/
    Route::get('about-us/edit/{slug}', 'DashboardController@aboutUsEdit')->name('aboutus.edit');
    Route::post('about-us/update', 'DashboardController@aboutUsUpdate')->name('aboutus.update');
    Route::get('about-us/services/list', 'DashboardController@servicesList')->name('aboutus.services.list');
    Route::get('about-us/services/edit/{id}', 'DashboardController@servicesEdit')->name('aboutus.services.edit');
    
    Route::get('about-us/team/list', 'DashboardController@teamList')->name('aboutus.team.list');
    Route::get('about-us/team/edit/{id}', 'DashboardController@teamEdit')->name('aboutus.team.edit');
/* About us manage routes ends*/

/* Slider Route Start*/
	Route::get('slider', 'DashboardController@getSlider')->name('slider.list');
	Route::get('slider/create', 'DashboardController@getSliderCreate')->name('slider.create');
	Route::post('slider/create', 'DashboardController@postSliderCreate')->name('slider.create.store');
	Route::get('slider/status/{id}/{type}', 'DashboardController@getSliderStatus')->name('slider.status');
	Route::get('slider/delete/{id}', 'DashboardController@getSliderDelete')->name('slider.delete');
	Route::get('slider/edit/{id}', 'DashboardController@getSliderEdit')->name('slider.edit');
	Route::post('slider/edit', 'DashboardController@postSliderEdit')->name('slider.edit.update');
/* Slider Route End*/

/* Review Route Start*/
	Route::get('review', 'DashboardController@getReview')->name('review.list');
	Route::get('review/create', 'DashboardController@getReviewCreate')->name('review.create');
	Route::post('review/create', 'DashboardController@postReviewCreate')->name('review.create.store');
	Route::get('review/status/{id}/{type}', 'DashboardController@getReviewStatus')->name('review.status');
	Route::get('review/delete/{id}', 'DashboardController@getReviewDelete')->name('review.delete');
	Route::get('review/edit/{id}', 'DashboardController@getReviewEdit')->name('review.edit');
	Route::post('review/edit', 'DashboardController@postReviewEdit')->name('review.edit.update');
/* Review Route End*/

/* Career Route Start*/
	Route::get('career', 'DashboardController@getCareer')->name('career.list');
	Route::get('career/create', 'DashboardController@getCareerCreate')->name('career.create');
	Route::post('career/create', 'DashboardController@postCareerCreate')->name('career.create.store');
	Route::get('career/status/{id}/{type}', 'DashboardController@getCareerStatus')->name('career.status');
	Route::get('career/delete/{id}', 'DashboardController@getCareerDelete')->name('career.delete');
	Route::get('career/edit/{id}', 'DashboardController@getCareerEdit')->name('career.edit');
	Route::post('career/edit', 'DashboardController@postCareerEdit')->name('career.edit.update');
/* Career Route End*/

/* Service Route Start*/
	Route::get('service', 'DashboardController@getService')->name('service.list');
	Route::get('service/create', 'DashboardController@getServiceCreate')->name('service.create');
	Route::post('service/create', 'DashboardController@postServiceCreate')->name('service.create.store');
	Route::get('service/status/{id}/{type}', 'DashboardController@getServiceStatus')->name('service.status');
	Route::get('service/delete/{id}', 'DashboardController@getServiceDelete')->name('service.delete');
	Route::get('service/edit/{id}', 'DashboardController@getServiceEdit')->name('service.edit');
	Route::post('service/edit', 'DashboardController@postServiceEdit')->name('service.edit.update');
/* Service Route End*/

/* Software Route Start*/
	Route::get('software', 'DashboardController@getSoftware')->name('software.list');
	Route::get('software/create', 'DashboardController@getSoftwareCreate')->name('software.create');
	Route::post('software/create', 'DashboardController@postSoftwareCreate')->name('software.create.store');
	Route::get('software/status/{id}/{type}', 'DashboardController@getSoftwareStatus')->name('software.status');
	Route::get('software/delete/{id}', 'DashboardController@getSoftwareDelete')->name('software.delete');
	Route::get('software/edit/{id}', 'DashboardController@getSoftwareEdit')->name('software.edit');
	Route::post('software/edit', 'DashboardController@postSoftwareEdit')->name('software.edit.update');
/* Software Route End*/