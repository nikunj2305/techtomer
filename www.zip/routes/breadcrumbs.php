<?php

//Just pointed it to where the breadcrumbs are located, in Http/Breadcrumbs/Backend
require __DIR__.'/../app/Http/Breadcrumbs/Backend/Backend.php';
